import * as THREE from 'three';
import {FBXLoader} from 'three/addons/loaders/FBXLoader.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';

const $=id=>document.getElementById(id);
const scene=new THREE.Scene();
scene.background=new THREE.Color(0x91a0a5);
scene.fog=new THREE.Fog(0x91a0a5,80,500);
const camera=new THREE.PerspectiveCamera(72,innerWidth/innerHeight,.05,1200);
const renderer=new THREE.WebGLRenderer({canvas:$('view'),antialias:false,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.5)); renderer.setSize(innerWidth,innerHeight); renderer.shadowMap.enabled=false;
scene.add(new THREE.HemisphereLight(0xffe8c0,0x334455,1.7));
const sun=new THREE.DirectionalLight(0xffe5bf,2.2); sun.position.set(100,200,50); scene.add(sun);

let map=null, mapBox=null, player={pos:new THREE.Vector3(),yaw:0,pitch:0,velY:0,onGround:false,hp:100,alive:true};
const raycaster=new THREE.Raycaster(), downRay=new THREE.Raycaster();
const bots=[], bullets=[];
let activeWeapon='primary', team='T', kills=0,deaths=0,shooting=false,lastShot=0;
const weapons={primary:{name:'AK-47',path:'./assets/weapons/ak/AK47.glb',rate:105,damage:34},awp:{name:'AWP',path:'./assets/weapons/awp/AWP.glb',rate:1200,damage:100},deagle:{name:'Desert Eagle',path:'./assets/weapons/deagle/DEAGLE.glb',rate:350,damage:55},knife:{name:'Butterfly Knife',path:'./assets/knife/butterflyknife.fbx',rate:500,damage:100}};
const weaponRoot=new THREE.Group(); camera.add(weaponRoot); scene.add(camera);
const loader=new GLTFLoader(), fbxLoader=new FBXLoader();
let weaponObj=null;

function fitObject(o,maxSize=1){
 const b=new THREE.Box3().setFromObject(o), s=b.getSize(new THREE.Vector3()), c=b.getCenter(new THREE.Vector3());
 o.position.sub(c); const m=Math.max(s.x,s.y,s.z); o.scale.multiplyScalar(maxSize/m); return o;
}
function setWeaponMaterial(o){
 o.traverse(n=>{if(n.isMesh){n.frustumCulled=false; if(n.material){n.material.roughness=.72; n.material.metalness=.25}}});
}
function loadWeapon(key){
 activeWeapon=key; const w=weapons[key]; $('weaponName').textContent=w.name;
 if(weaponObj){weaponRoot.remove(weaponObj);weaponObj=null}
 const done=o=>{weaponObj=fitObject(o,0.72); setWeaponMaterial(weaponObj); weaponObj.position.set(.34,-.27,-.63); weaponObj.rotation.set(0,Math.PI,0); weaponRoot.add(weaponObj); if(o.animations?.length){o.animations.forEach(a=>{});}};
 if(w.path.endsWith('.fbx')) fbxLoader.load(w.path,done,undefined,()=>{});
 else loader.load(w.path,g=>done(g.scene),undefined,()=>{});
}
function applyMapTextures(obj){
 const imgs=['part1','part2','part3','part4','part5','part6','part7','part8','part9a','part10','part11'];
 const tex=imgs.map(n=>new THREE.TextureLoader().load(`./assets/map/textures/${n}.jpg`));
 let idx=0;
 obj.traverse(n=>{
   if(n.isMesh){
     n.castShadow=false;n.receiveShadow=true;
     if(n.material){
       const mats=Array.isArray(n.material)?n.material:[n.material];
       mats.forEach((m,j)=>{
         if(!m.map) {m.map=tex[(idx+j)%tex.length];m.map.colorSpace=THREE.SRGBColorSpace;m.needsUpdate=true}
         m.roughness=.9;
       });
       idx++;
     }
   }
 });
}
function loadMap(){
 fbxLoader.load('./assets/map/dust2.fbx',obj=>{
   map=obj; applyMapTextures(obj);
   const box=new THREE.Box3().setFromObject(obj); mapBox=box;
   const size=box.getSize(new THREE.Vector3());
   // Normalize the imported CS1.6 FBX to a practical WebGL scale.
   const max=Math.max(size.x,size.y,size.z); obj.scale.multiplyScalar(260/max);
   box.setFromObject(obj);
   scene.add(obj);
   const center=box.getCenter(new THREE.Vector3());
   // Find a floor under the center; if the center is over an empty area, sample a few points.
   const top=box.max.y+200;
   const samples=[
     center.clone(), new THREE.Vector3(box.min.x*.2+box.max.x*.8,center.y,box.min.z*.5+box.max.z*.5),
     new THREE.Vector3(box.min.x*.5+box.max.x*.5,center.y,box.min.z*.2+box.max.z*.8)
   ];
   let found=null;
   for(const p of samples){downRay.set(new THREE.Vector3(p.x,top,p.z),new THREE.Vector3(0,-1,0));const h=downRay.intersectObject(obj,true)[0];if(h){found=h.point;break}}
   player.pos.copy(found||new THREE.Vector3(center.x,center.y,center.z)); player.pos.y+=2.0;
   camera.position.copy(player.pos);
   spawnBots();
 },undefined,e=>console.warn('FBX load failed',e));
}
function makeBot(teamColor){
 const g=new THREE.Group();
 const mat=new THREE.MeshStandardMaterial({color:teamColor,roughness:.85});
 const dark=new THREE.MeshStandardMaterial({color:0x252525,roughness:1});
 const body=new THREE.Mesh(new THREE.BoxGeometry(.55,1,.32),mat);body.position.y=1.0;g.add(body);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.24,10,8),dark);head.position.y=1.72;g.add(head);
 for(const x of [-.38,.38]){const a=new THREE.Mesh(new THREE.CapsuleGeometry(.10,.58,4,6),mat);a.position.set(x,1.0,0);a.rotation.z=x>0?-.15:.15;g.add(a)}
 for(const x of [-.17,.17]){const l=new THREE.Mesh(new THREE.BoxGeometry(.16,.72,.16),dark);l.position.set(x,.38,0);g.add(l)}
 return g;
}
function spawnBots(){
 for(let i=0;i<10;i++){
   const b=makeBot(i%2?0x5c77b8:0xc88943); b.userData={hp:100,team:i%2?'CT':'T',speed:.7+Math.random()*.5,target:new THREE.Vector3(),next:0};
   const r=10+Math.random()*30, a=Math.random()*Math.PI*2; b.position.copy(player.pos).add(new THREE.Vector3(Math.cos(a)*r,0,Math.sin(a)*r));
   b.position.y=player.pos.y; scene.add(b);bots.push(b);
 }
}
function shoot(){
 if(!player.alive)return;
 const now=performance.now(),w=weapons[activeWeapon]; if(now-lastShot<w.rate)return;lastShot=now;
 if(activeWeapon==='knife'){ // melee ray
   raycaster.setFromCamera(new THREE.Vector2(0,0),camera);const hits=raycaster.intersectObjects(bots,true);if(hits.length&&hits[0].distance<3) damageBot(hits[0].object,100);return;
 }
 raycaster.setFromCamera(new THREE.Vector2(0,0),camera);
 const targets=raycaster.intersectObjects(bots,true);
 if(targets.length && targets[0].distance<250) damageBot(targets[0].object,w.damage);
}
function damageBot(hit,dmg){
 let b=hit; while(b.parent&&!bots.includes(b))b=b.parent;
 if(!bots.includes(b))return;b.userData.hp-=dmg;
 if(b.userData.hp<=0){kills++;$('score').textContent=`${kills} : ${deaths}`; addFeed(`YOU  →  ${b.userData.team}`); respawnBot(b)}
}
function respawnBot(b){b.userData.hp=100;const r=25+Math.random()*35,a=Math.random()*Math.PI*2;b.position.copy(player.pos).add(new THREE.Vector3(Math.cos(a)*r,0,Math.sin(a)*r));}
function addFeed(t){const d=document.createElement('div');d.textContent=t;$('killfeed').prepend(d);setTimeout(()=>d.remove(),2200)}
function botAI(dt){
 for(const b of bots){
   if(b.userData.next<performance.now()){b.userData.next=performance.now()+1500+Math.random()*2500;b.userData.target.copy(player.pos).add(new THREE.Vector3((Math.random()-.5)*20,0,(Math.random()-.5)*20));}
   const v=b.userData.target.clone().sub(b.position);v.y=0;if(v.length()>1){v.normalize();b.position.addScaledVector(v,b.userData.speed*dt)}
   // tiny chance to shoot the player
   if(b.position.distanceTo(player.pos)<35 && Math.random()<dt*.12 && player.alive){player.hp-=8;$('hp').textContent=Math.max(0,player.hp|0);if(player.hp<=0)die()}
 }
}
function die(){player.alive=false;deaths++;$('score').textContent=`${kills} : ${deaths}`;$('respawn').style.display='block';addFeed('YOU  ←  BOT')}
$('respawn').onclick=()=>{player.hp=100;player.alive=true;$('hp').textContent='100';$('respawn').style.display='none';player.pos.y+=1};
function update(dt){
 if(!player.alive)return;
 const f=new THREE.Vector3(Math.sin(player.yaw),0,Math.cos(player.yaw)),r=new THREE.Vector3(Math.cos(player.yaw),0,-Math.sin(player.yaw));
 let move=joy; const dir=f.multiplyScalar(-move.y).add(r.multiplyScalar(move.x));if(dir.lengthSq())dir.normalize();
 player.pos.addScaledVector(dir,dt*5.5);player.velY-=18*dt;player.pos.y+=player.velY*dt;
 // floor probe
 if(map){downRay.set(player.pos.clone().add(new THREE.Vector3(0,4,0)),new THREE.Vector3(0,-1,0));const h=downRay.intersectObject(map,true)[0];if(h&&player.pos.y<h.point.y+1.7){player.pos.y=h.point.y+1.7;player.velY=0;player.onGround=true}}
 camera.position.copy(player.pos);camera.rotation.order='YXZ';camera.rotation.y=player.yaw;camera.rotation.x=player.pitch;
 botAI(dt);
 if(shooting)shoot();
}
let joy={x:0,y:0},joyTouch=null,aimTouch=null,lastAimX=0,lastAimY=0;
const joyEl=$('joystick'),stick=$('stick');
joyEl.addEventListener('touchstart',e=>{e.preventDefault();joyTouch=e.changedTouches[0].identifier;updateJoy(e.changedTouches[0])},{passive:false});
joyEl.addEventListener('touchmove',e=>{e.preventDefault();for(const t of e.changedTouches)if(t.identifier===joyTouch)updateJoy(t)},{passive:false});
joyEl.addEventListener('touchend',e=>{for(const t of e.changedTouches)if(t.identifier===joyTouch){joyTouch=null;joy={x:0,y:0};stick.style.transform='translate(0,0)'}}});
function updateJoy(t){const r=joyEl.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let x=(t.clientX-cx)/(r.width*.42),y=(t.clientY-cy)/(r.height*.42);const l=Math.hypot(x,y);if(l>1){x/=l;y/=l}joy={x,y};stick.style.transform=`translate(${x*r.width*.28}px,${y*r.height*.28}px)`}
$('aimZone').addEventListener('touchstart',e=>{e.preventDefault();aimTouch=e.changedTouches[0].identifier;lastAimX=e.changedTouches[0].clientX;lastAimY=e.changedTouches[0].clientY},{passive:false});
$('aimZone').addEventListener('touchmove',e=>{e.preventDefault();for(const t of e.changedTouches)if(t.identifier===aimTouch){const dx=t.clientX-lastAimX,dy=t.clientY-lastAimY;player.yaw-=dx*.006;player.pitch-=dy*.006;player.pitch=Math.max(-1.45,Math.min(1.45,player.pitch));lastAimX=t.clientX;lastAimY=t.clientY}},{passive:false});
$('aimZone').addEventListener('touchend',()=>aimTouch=null);
$('shoot').addEventListener('touchstart',e=>{e.preventDefault();shooting=true;shoot()},{passive:false});$('shoot').addEventListener('touchend',()=>shooting=false);
$('jump').onclick=()=>{if(player.onGround){player.velY=7;player.onGround=false}};
document.querySelectorAll('#weapons button').forEach(b=>b.onclick=()=>loadWeapon(b.dataset.slot));
$('playBtn').onclick=()=>{ $('menu').classList.add('hidden'); $('game').classList.remove('hidden'); start(); };
let started=false;
function start(){if(started)return;started=true;loadMap();loadWeapon('primary');}
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
let last=performance.now();
function loop(now){requestAnimationFrame(loop);const dt=Math.min(.033,(now-last)/1000);last=now;update(dt);renderer.render(scene,camera)}
requestAnimationFrame(loop);
